$(function(){
    console.log("jquery is ready!");
    const $input = $("#input");
    const $buttonAdd = $("#button-addon2");
    const $list = $(".list-items");
    const $delete = $("button-delete");
    const $listItems = $(".input-group");
    const $checkbox = $(".set-done");

    console.log($checkbox.length);
    $("#button-addon2").click(function(){
        console.log("clicks is ready!");

    });

    $buttonAdd.click(function(){
        if($input.val().length>0) {

            $list.append(
                `<div class="input-group mb-1">
                <div class="input-group-prepend">
                    <div class="input-group-text">
                        <input type="checkbox" class="set-done">
                    </div>
                </div>               
                <input type="text" class="input-item form-control" readonly value="${$input.val()}">     
                <div class="input-group-append">
                    <button class="btn btn-outline-secondary js_button-delete" type="button" data-toggle="modal" data-target="#exampleModal">Delete</button>
                </div>
                
                </div> `
                );
                $input.val('');
        }
        else{
            alert("You have not a texts!");
        }
    });
    $(document).on('change','.set-done', function(){
        console.log('Checked');
        $(this).parents('.input-group').toggleClass('done');
    })
    // $(document).on('click','.js_button-delete', function(){
    //     console.log('Remove');
    //     $(this).parents('.input-group').remove();
    // })
    // $checkbox.change(function(){
    //     console.log('Checked');
    // });
    // $delete.click(function(){
    //     debugger;
    //     $listItems.remove();
    // })
});
// https://themes.getbootstrap.com/
// https://themes.getbootstrap.com/
// https://themes.getbootstrap.com/